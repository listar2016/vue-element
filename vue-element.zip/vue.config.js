module.exports = {
  lintOnSave: false,
  devServer: {
    host: 'localhost',
  },
}
